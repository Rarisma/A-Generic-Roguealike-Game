Slots.txt breakdown
1 - Terrain
2 - Resource
3 - Enemys

Allowed Colors
BLACK, RED, GREEN, YELLOW, BLUE, MAGENTA, CYAN, WHITE, RESET

Allowed Brightnesses
DIM, NORMAL, BRIGHT, RESET_ALL